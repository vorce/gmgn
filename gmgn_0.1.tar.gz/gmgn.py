__version__ = "0.1"
__date__ = "2008-07-08"
__author__ = "Joel Carlbark (joelcb@gmail.com)"


import sys, string, os, threading, signal, urllib, urllib2
import HTMLParser, ConfigParser
try:
   import libgmail
except ImportError:
   print "No libgmail installed. Download at http://libgmail.sourceforge.net/"
   sys.exit(-1)
try:
   import Growl
except ImportError:
   print "No growl available. Downbload bindings at http://growl.info/"
   sys.exit(-1)

  

class ConfigFile:
   def __init__(self, fp=""):
      self.file = fp
      self.accounts = []
      self.cp = ConfigParser.SafeConfigParser()
      self.cp.read(self.file)
      
   def parseFile(self):
      for i in self.cp.sections():
         try:
            a = AccountConfig()
            a.type = self.cp.get(i, "Type") 
            a.username = self.cp.get(i, "Username")
            a.password = self.cp.get(i, "Password")
            noti = self.cp.get(i, "Notifications")
            if noti.lower() == "yes":
               a.notifications = True
            else:
               a.notifications = False
            a.interval = int(self.cp.get(i, "Interval"))
            # print a          
            self.accounts.append(a)
         except ConfigParser.NoOptionError:
            print "Error in section: " + i + " (incomplete options)"
            return
       
class AccountConfig:
   def __init__(self, user="", passw="", notify=False, typ="Gmail", iv=45):
      self.username = user
      self.password = passw
      self.notifications = notify
      self.type = typ # unused 
      self.interval = iv

   def __str__(self):
      result = []
      result.append("Username: %s" % self.username)
      result.append("Password: *")
      result.append("Account type: %s" % self.type)
      result.append("Notifications: %s" % self.notifications)
      result.append("Interval: %s" % self.interval)
      return '\n'.join(result)

class MLStripper(HTMLParser.HTMLParser):
   def __init__(self):
      self.reset()
      self.fed = []
   def handle_data(self, d):
      self.fed.append(d)
   def get_fed_data(self):
      return ''.join(self.fed)

class CheckMail(threading.Thread):
   def __init__(self, acc):
      self.account = acc
      threading.Thread.__init__(self, name="Thread.%s" % self.account.username)
      self._finished = threading.Event()
      signal.signal(signal.SIGINT, signal.SIG_DFL)
      
      if self.account.interval > 20:
         self._interval = self.account.interval
      else:
         self._interval = 40

      self.unread_threads = []
      self.gotmail = False
      self.unread = 0

      self.name = "GMGN"
      self.notifications = ["Unread mail"]
      self.notifier = None
            
      self.ga = libgmail.GmailAccount(self.account.username, self.account.password)

   # create/get growl notifier
   def getNotifier(self):
      if self.notifier == None:
         self.notifier = Growl.GrowlNotifier(self.name, self.notifications)
         self.notifier.register()
      return self.notifier

   # stop thread
   def shutdown(self, timeout=None):
      self._finished.set()
     #  threading.Thread.join(self, timeout)

   def run(self):
      while not self._finished.isSet():
        self.checkMail()
        self._finished.wait(self._interval)
      # threading.Thread.join(self)

   # compare to see if two list of threads are the same
   # so ugly it hurts.
   def threadListsAreEqual(self, t1, t2):
      tl1 = []
      tl2 = []
      for t in t1:
        tl1.append((t.id, len(t)))
      for t in t2:
        tl2.append((t.id, len(t)))
      return tl1 == tl2

   # TODO: 
   #   * different outputs depending on number of new mails:
   #	   1 mail only: Output subject, authors and snippet
   #       2 or more: Output only "you have N new mails"
   #
   #   * remember how many unread mails the user has, don't show
   #       them when another new pops in...ex:
   #       user has 100 unread in his mailbox. on first run show
   #       "you have 100 unread messages". on second run show
   #       "no new mails". Now when a new mail drops in, we show:
   #       "You have one new mail from bnla@anksfl.com: subject, snippet"
   #       also; if user reads one of the 100, so he only has 99
   #       unread we should not notify at all. only say 99 unread.
   #
   #   * strip html from subject, author, snippet
   def checkMail(self):
      print "Checking mail for %s" % self.account.username
      try: self.ga.login()
      except urllib2.URLError, (err):
         print "URL error (%s)" % (err)
         return
      except libgmail.GmailLoginFailure, (err):
         print "Gmail Login Failure (%s)" % (err)
         print "\tDisabling checking for the account: %s" % self.account.username
         self.shutdown()
         return

      new_unread = self.ga.getUnreadMessages()
      new_unread_num = len(new_unread._threads)
     
      if not self.threadListsAreEqual(new_unread._threads, self.unread_threads) and new_unread_num >= self.unread:
        self.gotmail = True
        #print "You got mail!"
        #if self.new_unread_num > self.unread:
        #    print "You have " + str(self.unread) + " unread messages."
        for t in new_unread:
            msg = "Subject: " + t.subject + "\nAuthor(s): " + t._authors + "\nSnippet: " + t.snippet
            msg = msg.decode("unicode-escape") # took me like 4 hours to dig up this line..
            hs = MLStripper() # can you say overkill?
            hs.feed(msg)
            msg = hs.get_fed_data()
            if self.account.notifications:
               self.getNotifier().notify("Unread mail", "Unread mail for %s" % self.account.username, msg)
#print "Unread mail: " + msg
            #for m in reversed(t):
            #    print "From: " + m.author
            #    break
        self.unread_threads = new_unread._threads
        self.unread = new_unread_num
        # growl notification kk
        
      elif new_unread_num > 0:
        self.unread = new_unread_num
        print "\tNo new mails. But still " + str(self.unread) + " unread."
      #else:
        # print "No new mails, no one loves you."


if(len(sys.argv)) != 2:
   print "Usage: gmgn.py foo.conf"
   sys.exit(1)

cf = ConfigFile(sys.argv[1])
cf.parseFile()
for a in cf.accounts:
   cm = CheckMail(a)
   signal.signal(signal.SIGINT, signal.SIG_DFL)
   cm.start()

